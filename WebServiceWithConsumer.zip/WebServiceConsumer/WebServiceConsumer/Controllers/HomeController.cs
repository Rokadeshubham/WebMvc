﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace WebServiceConsumer.Controllers
{
    public class HomeController : Controller
    {
        StudentServiceReference.StudentWebServiceSoapClient soap = new StudentServiceReference.StudentWebServiceSoapClient();
        // GET: Home
        public ActionResult Index()
        {
            return View(soap.GetStudent().ToList());
        }

        public ActionResult Get()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetById(string rollno)
        {
            return View(soap.GetInfoById(Convert.ToInt32(rollno)).ToList());
        }
    }
}