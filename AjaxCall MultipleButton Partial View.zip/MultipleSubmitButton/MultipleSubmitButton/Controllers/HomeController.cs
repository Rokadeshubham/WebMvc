﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MultipleSubmitButton.Models;

namespace MultipleSubmitButton.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Employee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Save(EmployeeModel objSave)
        {
            ViewBag.Msg = "Data Saved successfully";
            return View("Employee");
        }
        [HttpPost]
        public ActionResult Draft(EmployeeModel objDraft)
        {
            ViewBag.Msg = "Draft saved successfully";
            return View("Employee");
        }
    }
}