﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AJAXCALL.Models;

namespace AJAXCALL.Controllers
{
    public class HomeController : Controller
    {
        StudentTableEntities entities = new StudentTableEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public PartialViewResult All()
        {
            List<Student> model = entities.Students.ToList();
            return PartialView("_Student", model);
        }


        public PartialViewResult Top3()
        {
            List<Student> model = entities.Students.OrderByDescending(x => x.Score).Take(3).ToList();
            return PartialView("_Student", model);
        }

        // Return Bottom3 students
        public PartialViewResult Bottom3()
        {
            List<Student> model = entities.Students.OrderBy(x => x.Score).Take(3).ToList();
            return PartialView("_Student", model);
        }



    }
}