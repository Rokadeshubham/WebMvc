﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PartialAndRenderPartial.Models;

namespace PartialAndRenderPartial.Controllers
{
    public class HomeController : Controller
    {
        StudentEntities entities = new StudentEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View(entities.Students.ToList());
        }

        public PartialViewResult Student()
        {
            return PartialView("_student");
        }


        public ActionResult Dropdown()
        {
            return Json(entities.Students.Select(x => new
            {
                RollNo = x.RollNo,
                FirstName = x.FirstName
            }).ToList(), JsonRequestBehavior.AllowGet);
        }
    }
}