﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractExample
{
    class Program
    {
        static void Main(string[] args)
        {

            FullTimeEmployee fte = new FullTimeEmployee()
            {
                FirstName = "Shubham",
                LastName = "Rokade",
                AnnualSalary = 150000
            };
            Console.WriteLine(fte.GetFullName());
            Console.WriteLine(fte.GetMonthlySalary());
            Console.WriteLine("**************************");
            ContractEmployee ce = new ContractEmployee()
            {
                FirstName = "John",
                LastName = "Cena",
                HourlyPay = 150,
                TotalHours = 100
            };

            Console.WriteLine(ce.GetFullName());
            Console.WriteLine(ce.GetMonthlySalary());
        }
    }
}
