﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AjaxAndCodeFirst.Models;
namespace AjaxAndCodeFirst.Controllers
{
    public class StudentController : Controller
    {
        StudentContext entities = new StudentContext();
        // GET: Student
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public ActionResult createStudent(Students std)
        {
            entities.Students.Add(std);
            entities.SaveChanges();
            string message = "SUCCESS";
            return Json(new { Message = message, JsonRequestBehavior.AllowGet });
            
        }

        [HttpGet]
        public JsonResult GetStudents(string id)
        {
            List<Students> students = new List<Students>();
            students = entities.Students.ToList();
            return Json(students, JsonRequestBehavior.AllowGet);
        }
    }
}