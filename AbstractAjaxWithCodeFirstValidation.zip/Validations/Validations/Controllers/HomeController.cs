﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Validations.Models;

namespace Validations.Controllers
{
    public class HomeController : Controller
    {
        StudentTableEntities entities = new StudentTableEntities();
        
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(FormCollection fm)
        {
            Student student = new Student();
            student.Name = fm["Name"];
            student.Score =Convert.ToInt32(fm["Score"]);
            entities.Students.Add(student);
            entities.SaveChanges();
            return View();
        }
    }
}