﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EventApp.Models
{
    public class RegisterEventModel
    {
        public int EventId { get; set; }
        public DateTime?StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public IEnumerable<SelectListItem> eventlist { get; set; }
        public int RegId { get; set; }

    }
}