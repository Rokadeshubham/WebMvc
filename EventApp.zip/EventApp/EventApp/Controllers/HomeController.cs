﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EventApp.Models;

namespace EventApp.Controllers
{
    public class HomeController : Controller
    {

        EventsEntities entities = new EventsEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(UserInfo info)
        {
            var user = entities.UserInfoes.FirstOrDefault(u=>u.UserName.Equals(info.UserName) && u.Password.Equals(info.Password));
            if (user !=null)
            {
                var role = entities.UserInfoes.FirstOrDefault(u => u.UserName.Equals(info.UserName) && u.Password.Equals(info.Password)).Role;
                if (role == "Admin")
                {
                    Session["UserName"] = user.UserName;
                    Session["UserID"] = user.UserId;
                    return RedirectToAction("Admin");
                }
                if (role == "User")
                {
                    Session["UserName"] = user.UserName;
                    Session["UserID"] = user.UserId;
                    return RedirectToAction("User");
                }
            }else
            {
                return RedirectToAction("Loginfail");
            }
            return View();
        }

        public ActionResult Loginfail()
        {
            return View();
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Index");
        }

        public ActionResult Admin()
        {
            return View(entities.DisplayEvents().ToList());
        }

        public ActionResult User()
        {
            int id = Convert.ToInt32( Session["UserID"]);
            return View(entities.DisplayEventsByUser(id).ToList());
        }
       



        public ActionResult CreateEvent()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateEvent(EventTable ev)
        {
            //ViewBag.Msg = "Event Added Successfully";
            //EventTable ev = new EventTable();
            //ev.UserId = Convert.ToInt32(Session["UserID"]);
            //ev.EventName = fm["EventName"];
            //ev.Date = Convert.ToDateTime(fm["Date"]);
            //ev.City = fm["City"];
            entities.EventTables.Add(ev);
            entities.SaveChanges();
            return View();
        }
       
        public ActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Delete(int id)
        {
            var user = entities.EventTables.FirstOrDefault(e => e.EventId == id);
            entities.EventTables.Remove(user);
            entities.SaveChanges();
            return RedirectToAction("Admin");
        }


        public ActionResult Upcoming()
        {
            return View(entities.UpcomingEvents().ToList());
        }
        [HttpPost]
        public ActionResult UserSearch(FormCollection fm)
        {
            string name = fm["EventName"];
            var result = entities.EventTables.Where(x=>x.EventName.Contains(name)).ToList();
            List<EventSearchModel> eventsearchmodel = new List<EventSearchModel>();
            eventsearchmodel = result.Select(x => new EventSearchModel
            {
                EventId = x.EventId,
                UserId =Convert.ToInt32(x.UserId),
                EventName = x.EventName,
                Date = Convert.ToDateTime(x.Date),
                City = x.City
            }
            ).ToList();
            return PartialView(eventsearchmodel);

        }

        public ActionResult AddEventForRegister()
        {
            RegisterEventModel reg = new RegisterEventModel();
            //List<SelectListItem> selectListItems = new List<System.Web.Mvc.SelectListItem>();
            //foreach (EventTable item in entities.EventTables)
            //{
            //    SelectListItem selectlistItem = new SelectListItem
            //    {
            //        Text = item.EventName,
            //        Value = item.EventId.ToString()



            //    };
            //    selectListItems.Add(selectlistItem);

            //}

            //ViewBag.ActiveEvents = new SelectList(entities.EventTables.ToList(),"EventId","EventName");
            //ViewData.Drop = result;
            //var result= entities.EventTables.ToList();
            //reg.eventlist = result.Select(x => new SelectListItem {
            //    Text=x.EventName,
            //    Value=Convert.ToString(x.EventId)
            //}).ToList();
            //ViewBag.EventDropdown =new SelectList( entities.EventTables,"EventId","EventName");
            ViewBag.EventDropdown =entities.EventTables.ToList();
            return View();
        }
        [HttpPost]
        public ActionResult AddEventForRegister(RegisterEvent fm)
        {
            //RegisterEvent re = new RegisterEvent();
            //re.EventId =Convert.ToInt32(fm["EventId"]);
            //re.StartDate = Convert.ToDateTime(fm["StartDate"]);
            //re.EndDate = Convert.ToDateTime(fm["EndDate"]);
            ////RegisterEvent reg = new RegisterEvent() {
            ////    EventId=fm.EventId,
              
            ////};

            entities.RegisterEvents.Add(fm);
            entities.SaveChanges();
            ViewBag.Msg = "Event Added Successfully";
            return RedirectToAction(nameof(AddEventForRegister));
        }



        public ActionResult UserEvent()
        {
            ViewBag.ErrorMsg = "";
            return View(entities.EventInformation().ToList());
        }

      
        public ActionResult RegisteredSuccess(int id)
        {
            int newId = Convert.ToInt32(Session["UserId"]);
            RegisteredUser newuser = entities.RegisteredUsers.Where(s => s.RegId == id && s.UserId == newId).FirstOrDefault();
            if (newuser == null)
            {
                RegisteredUser ru = new RegisteredUser();
                ru.RegId = id;
                ru.UserId = Convert.ToInt32(Session["UserId"]);
                entities.RegisteredUsers.Add(ru);
                entities.SaveChanges();
            }
            else
            {
                ViewBag.ErrorMsg = "This user is already Reagistered";
                return View();
            }
            ViewBag.Success = "Successfully Registered"; 
            return View();
        }
    }
}