﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EventApp.Models;

namespace EventApp.Controllers
{
    public class HomeController : Controller
    {

        EventsEntities entities = new EventsEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(UserInfo info)
        {
            var user = entities.UserInfoes.FirstOrDefault(u=>u.UserName.Equals(info.UserName) && u.Password.Equals(info.Password));
            if (user !=null)
            {
                var role = entities.UserInfoes.FirstOrDefault(u => u.UserName.Equals(info.UserName) && u.Password.Equals(info.Password)).Role;
                if (role == "Admin")
                {
                    Session["UserName"] = user.UserName;
                    Session["UserID"] = user.UserId;
                    return RedirectToAction("Admin");
                }
                if (role == "User")
                {
                    Session["UserName"] = user.UserName;
                    Session["UserID"] = user.UserId;
                    return RedirectToAction("User");
                }
            }else
            {
                return RedirectToAction("Loginfail");
            }
            return View();
        }

        public ActionResult Loginfail()
        {
            return View();
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Index");
        }

        public ActionResult Admin()
        {
            return View(entities.DisplayEvents().ToList());
        }

        public ActionResult User()
        {
            int id = Convert.ToInt32( Session["UserID"]);
            return View(entities.DisplayEventsByUser(id).ToList());
        }
       



        public ActionResult CreateEvent()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateEvent(FormCollection fm)
        {
            ViewBag.Msg = "Event Added Successfully";
            EventTable ev = new EventTable();
            ev.UserId = Convert.ToInt32(Session["UserID"]);
            ev.EventName = fm["EventName"];
            ev.Date = Convert.ToDateTime(fm["Date"]);
            ev.City = fm["City"];
            entities.EventTables.Add(ev);
            entities.SaveChanges();
            return View();
        }
       
        public ActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Delete(int id)
        {
            var user = entities.EventTables.FirstOrDefault(e => e.EventId == id);
            entities.EventTables.Remove(user);
            entities.SaveChanges();
            return RedirectToAction("Admin");
        }


        public ActionResult Upcoming()
        {
            return View(entities.UpcomingEvents().ToList());
        }
        [HttpPost]
        public ActionResult UserSearch(FormCollection fm)
        {
            string name = fm["EventName"];
            var result = entities.EventTables.Where(x=>x.EventName.Contains(name)).ToList();
            List<EventSearchModel> eventsearchmodel = new List<EventSearchModel>();
            eventsearchmodel = result.Select(x => new EventSearchModel
            {
                EventId = x.EventId,
                UserId =Convert.ToInt32(x.UserId),
                EventName = x.EventName,
                Date = Convert.ToDateTime(x.Date),
                City = x.City
            }
            ).ToList();
            return PartialView(eventsearchmodel);

        }

        
    }
}